# `format-path`

> TODO: description

## Usage

```
const formatPath = require('format-path');

// TODO: DEMONSTRATE API
```
