'use strict';

const init = require('..');

describe('init', () => {
    it('needs tests');
});
