# `exec`

> TODO: description

## Usage

```
const exec = require('exec');

// TODO: DEMONSTRATE API
```
