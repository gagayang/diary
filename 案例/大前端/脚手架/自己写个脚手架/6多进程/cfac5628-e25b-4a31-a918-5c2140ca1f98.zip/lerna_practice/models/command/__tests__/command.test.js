'use strict';

const command = require('..');

describe('command', () => {
    it('needs tests');
});
