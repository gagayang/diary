120.52.32.211 ucres.100tal.com
120.52.32.211 app.arts.xueersi.com
120.52.32.211 app.chs.xueersi.com
120.52.32.211 imapp.xueersi.com
120.52.32.211 adminapp.xesv5.com
120.52.32.211 pzcenter.xueersi.com
120.52.32.211 appweb.xesv5.com
120.52.32.211 mq.xesv5.com
120.52.32.211 api.xueersi.com
120.52.32.211 app-inner.xesv5.com 

# 前台项目
120.52.32.211 libs.xesimg.com
120.52.32.211 ocenter.xueersi.com
120.52.32.211 trade.xueersi.com
120.52.32.211 account.xueersi.com
120.52.32.211 open.xueersi.com
120.52.32.211 home.xueersi.com

120.52.32.211 record.xueersi.com
120.52.32.211 eolinker.xesv5.com
120.52.32.211 laoshi.xueersi.com
120.52.32.204 teachercenter.xesv5.com
120.52.32.204 teacheradmin.xesv5.com
10.90.70.103 adminapi.xesv5.com


10.90.70.71 userapi.xesv5.com
10.90.70.32 courseapi.xesv5.com
10.90.70.103 promotionapi.xesv5.com
#10.90.70.103 stucouapi.xesv5.com
10.90.70.103 orderapi.xesv5.com
10.90.70.103 cardcouponapi.xesv5.com
10.90.70.52  stucouapi.xesv5.com
# 后台项目
120.52.32.211 admin.xesv5.com
120.52.32.211 custom.xesv5.com
120.52.32.211 accountmgr.xesv5.com
120.52.32.211 express.xesv5.com
120.52.32.211 static.xesv5.com
120.52.32.211 appeal.xesv5.com
120.52.32.211 appealadmin.xesv5.com
120.52.32.211 erp.xesv5.com
120.52.32.211 libs.xesimg.com
120.52.32.211 erpapi.xesv5.com
# 120.52.32.204 erpadmin.xesv5.com
120.52.32.211 record.xesv5.com
120.52.32.211 recruit.xesv5.com
120.52.32.211 admin.sms.xesv5.com

# 老项目
120.52.32.211 admin.xueersi.com
120.52.32.211 video.xueersi.com
120.52.32.211 otms.xesv5.com

# 项目依赖
120.52.32.211 login.xueersi.com
120.52.32.211 reg.xueersi.com
120.52.32.211 www.xueersi.com
120.52.32.211 i.xueersi.com
120.52.32.211 t.xueersi.com
120.52.32.211 cart.xueersi.com
120.52.32.211 mall.xueersi.com
120.52.32.211 mallimg.xesimg.com




120.52.32.211 res01.xesimg.com
120.52.32.211 res02.xesimg.com
120.52.32.211 res03.xesimg.com
120.52.32.211 res04.xesimg.com
120.52.32.211 res05.xesimg.com
120.52.32.211 res06.xesimg.com
120.52.32.211 res11.xesimg.com
120.52.32.211 res12.xesimg.com
120.52.32.211 res13.xesimg.com
120.52.32.211 res14.xesimg.com
120.52.32.211 res15.xesimg.com
120.52.32.211 res16.xesimg.com
120.52.32.211 res17.xesimg.com
120.52.32.211 res18.xesimg.com
120.52.32.211 lib01.xesimg.com
120.52.32.211 lib02.xesimg.com
120.52.32.211 lib03.xesimg.com
120.52.32.211 lib04.xesimg.com

120.52.32.211 img03.xesimg.com
120.52.32.211 css03.xesimg.com
120.52.32.211 js03.xesimg.com
120.52.32.211 img04.xesimg.com
120.52.32.211 css04.xesimg.com
120.52.32.211 js04.xesimg.com
120.52.32.211 static.xesimg.com
120.52.32.211 res01.xesimg.com
120.52.32.211 res02.xesimg.com
120.52.32.211 res03.xesimg.com
120.52.32.211 res04.xesimg.com
120.52.32.211 res05.xesimg.com
120.52.32.211 res06.xesimg.com
120.52.32.211 xes01.xesimg.com
120.52.32.211 xes02.xesimg.com
120.52.32.211 xes03.xesimg.com
120.52.32.211 xes04.xesimg.com
120.52.32.211 flash.xesimg.com
120.52.32.211 res16.xesimg.com


10.90.71.118 autocounselor.xesv5.com
120.52.32.211 biz.xesv5.com


#120.52.32.211 passport.100tal.com
120.52.32.211 ucres.100tal.com

120.52.32.211 app.arts.xueersi.com
120.52.32.211 app.chs.xueersi.com
120.52.32.211 imapp.xueersi.com

120.52.32.211 adminapp.xesv5.com
120.52.32.211 pzcenter.xueersi.com

120.52.32.211 appweb.xesv5.com
120.52.32.211 mq.xesv5.com

0.0.0.0 account.jetbrains.com
0.0.0.0 www.jetbrains.com

120.52.32.211 livemanage.xesv5.com
10.90.70.52 stucouv2api.xesv5.com 
10.90.70.32 coursev2api.xesv5.com
120.52.32.211 bizadmin.xesv5.com

# 巴别塔
10.90.72.118 abadmin.xesv5.com

# ERP
120.52.32.211 erpapi.xesv5.com
# 120.52.32.211 erpadmin.xesv5.com
120.52.32.211 erp.xesv5.com

#配置中心
10.90.70.102 configure.xesv5.com
10.90.70.102 configureadmin.xesv5.com

10.90.70.68 otmsapi.xesv5.com



#课程管理平台
120.52.32.211 app.xesv5.com
#图片上传
120.52.32.211 upload.xueersi.com
#建课脚本
10.170.78.13 appserver.ad.xesv5.com
#K8s
120.52.32.211 k8stest.xesv5.com
10.90.70.52 classapi.xesv5.com

# 海外业务平台
49.51.177.159 beta-admin.thethinkacademy.com
# 新业务系统
49.51.177.159 beta-bms-admin.thethinkacademy.com

# 后端海外业务平台接口
49.51.177.159 beta-official.thethinkacademy.com
# 后端海外业务系统接口
49.51.177.159 biz-beta.thethinkacademy.com
# 后端教师中心接口
49.51.177.159 master-teacher-dev.thethinkacademy.com

#海外平台
#海外业务平台
49.51.177.159 beta-admin.thethinkacademy.com
#新业务系统
49.51.177.159 beta-bms-admin.thethinkacademy.com
#后端海外业务平台接口
49.51.177.159 beta-official.thethinkacademy.com
#后端海外业务系统接口
49.51.177.159 biz-beta.thethinkacademy.com
#后端教师中心接口
# 49.51.177.159 master-teacher-dev.thethinkacademy.com

49.51.177.159 beta-one.thethinkacademy.com
120.52.32.211 booster.xueersi.com
35.165.80.0 api-beta.thethinkacademy.com
45.51.177.159 app-upgrade-beta.thethinkacademy.com
172.24.78.58 chatapi.xescdn.com
49.51.177.159 app-upgrade-beta.thethinkacademy.com
54.188.205.219 chatpush.msg.xescdn.com
54.188.205.219 chatgslb.xescdn.com
54.188.205.219 chatgslb.xesimg.com
52.32.144.28 chatastest.msg.xescdn.com
54.188.205.219 lecturegslb.msg.xescdn.com
170.106.135.222 beta-touch.thinkacademy.uk
49.51.181.115 beta-touch.thinkacademy.sg
49.51.177.159 beta-touch.thethinkacademy.com

10.90.70.103  api.xesv5.com
#10.90.70.52 api.xesv5.com
#优网接口线上
54.244.15.236 inner-api.thethinkacademy.com
#Jenkins
120.52.32.211 jenkins-test-a.xesv5.com
#磐石平台
10.90.73.142  apits.xesv5.com

# 供应链
120.52.32.204 scm.xesv5.com
# 127.0.0.1 scm.xesv5.com
120.52.32.204 erpadmin.xesv5.com
# 10.90.103.60 erpadmin.xesv5.com
127.0.0.1 localhost
120.52.32.204 app.xueersi.com
# 日志
120.52.32.204 dj.xesimg.com
120.52.32.204 logcenter-test.xesv5.com
120.52.32.204 logcenteradmin-test.xesv5.com
120.52.32.204  cloud-test.tal.com


