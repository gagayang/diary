'use strict';

const formatPath = require('..');

describe('format-path', () => {
    it('needs tests');
});
