'use strict';

const package = require('..');

describe('package', () => {
    it('needs tests');
});
