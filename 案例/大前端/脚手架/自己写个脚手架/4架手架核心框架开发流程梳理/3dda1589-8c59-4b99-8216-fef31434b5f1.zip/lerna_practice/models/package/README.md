# `package`

> TODO: description

## Usage

```
const package = require('package');

// TODO: DEMONSTRATE API
```
