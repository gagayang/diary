'use strict';

const exec = require('..');

describe('exec', () => {
    it('needs tests');
});
