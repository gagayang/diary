'use strict';

const log = require('..');

describe('log', () => {
    it('needs tests');
});
