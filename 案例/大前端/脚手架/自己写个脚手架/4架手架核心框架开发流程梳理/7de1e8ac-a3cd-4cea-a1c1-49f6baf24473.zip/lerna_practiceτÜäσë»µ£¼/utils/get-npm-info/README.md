# `get-npm-info`

> TODO: description

## Usage

```
const getNpmInfo = require('get-npm-info');

// TODO: DEMONSTRATE API
```
