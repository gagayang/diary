'use strict';

const getNpmInfo = require('..');

describe('get-npm-info', () => {
    it('needs tests');
});
