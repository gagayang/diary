# `log`

> TODO: description

## Usage

```
const log = require('log');

// TODO: DEMONSTRATE API
```
