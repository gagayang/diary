1、国内appid注册：

注册中国区appid：https://www.youtube.com/watch?v=5JwWnK4FnJg

登录：https://appleid.apple.com/sign-in

2、更改appid（从国内改为国外)，最好是免税州的地址

注册前没有VPN，最好先有了VPN再切换国家

博文：https://github.com/kjfx/AppleID

视频教程：https://www.youtube.com/watch?v=5JwWnK4FnJg

![1699947848709](image/chatgpt/1699947848709.png)

3、注册chatgpt账号

教学：https://www.youtube.com/watch?v=_PHdzsQaDgw

注册chatgpt（https://openai.com/)前，需要有一个国外的手机号，虚拟手机电话注册，https://sms-activate.org/cn，注册：账号：denkezwei@gmail.com，密码：Wang822703，登录这个网站，买虚拟号需要2美元左右

step3：

4、app登录

ios：https://www.youtube.com/watch?v=JpNGoEXoa3s

安卓：https://www.youtube.com/watch?v=LtzKUotTt7w
