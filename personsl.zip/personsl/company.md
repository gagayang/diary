# wifi/sso/**邮箱**

邮箱前缀

Wang@82270392

# 开机密码：

Wang@8227

# iphone密码：

030506


# 两步验证：

Wang@82270392

# 本地Mysql：

wang123456

# 本地mysql：

mysql -uroot -p

wang123456


TT测试包邮箱密码：

wanglong.denkezwei@....com

Wang@82270392
